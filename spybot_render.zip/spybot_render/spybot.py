from telethon import TelegramClient, events
from datetime import datetime

api_id = 24874443       # замените на ваш api_id (число)
api_hash = 'db32eb78c9b31eab016b33beed768f99' # замените на ваш api_hash (строка)

client = TelegramClient('session_name', api_id, api_hash)

message_store = {}

@client.on(events.NewMessage)
async def new_message_handler(event):
    key = (event.chat_id, event.message.id)
    message_store[key] = event.message
    print(f"[NEW] {datetime.now()} | {event.chat.title if event.chat else 'PM'}: {event.message.sender_id} - {event.message.text}")

@client.on(events.MessageEdited)
async def edited_handler(event):
    key = (event.chat_id, event.message.id)
    old = message_store.get(key)
    new = event.message
    print(f"[EDITED] {datetime.now()} | Было: {old.text if old else '?'} → Стало: {new.text}")
    message_store[key] = new

@client.on(events.MessageDeleted)
async def deleted_handler(event):
    for msg_id in event.deleted_ids:
        key = (event.chat_id, msg_id)
        old = message_store.get(key)
        if old:
            print(f"[DELETED] {datetime.now()} | {old.sender_id}: {old.text}")
        else:
            print(f"[DELETED] {datetime.now()} | Неизвестное сообщение с ID {msg_id}")

client.start()
print("🔍 Шпион-бот работает...")
client.run_until_disconnected()
LOG_CHAT_ID = 1973666613  # замените на ваш chat_id, например свой ID или ID группы

@client.on(events.MessageDeleted)
async def deleted_handler(event):
    for msg_id in event.deleted_ids:
        key = (event.chat_id, msg_id)
        old = message_store.get(key)

        if old:
            text = f"📛 Удалено сообщение\n👤 Отправитель: {old.sender_id}\n📅 Дата: {old.date}\n💬 Текст: {old.text or '[без текста]'}"
            await client.send_message(LOG_CHAT_ID, text)
            if old.media:
                await client.send_file(LOG_CHAT_ID, old.media, caption="🗑 Удалённый медиафайл")
        else:
            await client.send_message(LOG_CHAT_ID, f"Удалено неизвестное сообщение ID {msg_id}")